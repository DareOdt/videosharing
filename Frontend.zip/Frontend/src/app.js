import { loadHomePage } from './pages/homePage.js';
import { loadSignUpPage } from './pages/signUpPage.js';
import { loadCreatorDashboard } from './pages/creatorDashboard.js';

export function handleRouteChange(route, container) {
  // Clear the container before rendering
  container.innerHTML = '';

  // Render the appropriate page based on the route
  switch (route) {
    case '#home':
      loadHomePage(container);
      break;
    case '#signup':
      loadSignUpPage(container);
      break;
    case '#dashboard':
      loadCreatorDashboard(container);
      break;
    default:
      loadHomePage(container); // Default to home page
  }
}

