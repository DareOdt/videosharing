import { renderVideoList } from '../components/videoList.js';

export function loadHomePage(container) {
  container.innerHTML = `
    <section class="hero">
      <div class="hero-content">
        <h2>Welcome to VidShare</h2>
        <p>Share your moments, connect with others, and explore the world of short-form videos.</p>
        <a href="#signup" class="btn-primary">Get Started</a>
      </div>
    </section>
    <section class="videos"></section>
  `;

  // Render the video list in the "videos" section
  const videoContainer = container.querySelector('.videos');
  renderVideoList(videoContainer);
}
