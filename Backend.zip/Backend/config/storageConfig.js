module.exports = {
  storageAccount: process.env.STORAGE_ACCOUNT,
  storageKey: process.env.STORAGE_KEY,
  containerName: process.env.CONTAINER_NAME,
};
